import React, { useState } from "react";
import "./App.css";
import TabNav from "./components/TabNav";
import TodoApp from "./components/TodoApp";
import NotesApp from "./components/NotesApp";

const TABS = [
  { id: "tasks", label: "Tasks" },
  { id: "notes", label: "Notes" },
];

export default function App() {
  const [activeTab, setActiveTab] = useState("tasks");

  return (
    <div className="shell">
      <header className="shell__header">
        <div className="shell__mark" aria-hidden="true">
          §
        </div>
        <div>
          <p className="shell__eyebrow">A desk for the day's work</p>
          <h1 className="shell__title">Ledger</h1>
        </div>
      </header>

      <TabNav tabs={TABS} activeTab={activeTab} onChange={setActiveTab} />

      <main className="shell__panel">
        {activeTab === "tasks" ? <TodoApp /> : <NotesApp />}
      </main>

      <footer className="shell__footer">
        <span>Built with React — tasks and notes, kept in one place.</span>
      </footer>
    </div>
  );
}
