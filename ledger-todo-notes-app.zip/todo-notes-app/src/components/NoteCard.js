import React, { useState } from "react";

export default function NoteCard({ note, onUpdate, onDelete }) {
  const [isEditing, setIsEditing] = useState(false);
  const [draftTitle, setDraftTitle] = useState(note.title);
  const [draftBody, setDraftBody] = useState(note.body);

  const startEdit = () => {
    setDraftTitle(note.title);
    setDraftBody(note.body);
    setIsEditing(true);
  };

  const saveEdit = () => {
    onUpdate(note.id, {
      title: draftTitle.trim() || "Untitled",
      body: draftBody.trim(),
    });
    setIsEditing(false);
  };

  return (
    <article className={`note note--${note.hue}`}>
      <span className="note__pin" aria-hidden="true" />

      {isEditing ? (
        <div className="note__edit">
          <input
            className="note__edit-title"
            value={draftTitle}
            onChange={(e) => setDraftTitle(e.target.value)}
            aria-label="Edit note title"
            autoFocus
          />
          <textarea
            className="note__edit-body"
            rows={4}
            value={draftBody}
            onChange={(e) => setDraftBody(e.target.value)}
            aria-label="Edit note body"
          />
          <div className="note__actions">
            <button className="note__save" onClick={saveEdit}>
              Save
            </button>
            <button
              className="note__cancel"
              onClick={() => setIsEditing(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <>
          <h3 className="note__title">{note.title}</h3>
          {note.body && <p className="note__body">{note.body}</p>}
          <div className="note__actions">
            <button className="note__edit-btn" onClick={startEdit}>
              Edit
            </button>
            <button
              className="note__delete"
              onClick={() => onDelete(note.id)}
            >
              Delete
            </button>
          </div>
        </>
      )}
    </article>
  );
}
