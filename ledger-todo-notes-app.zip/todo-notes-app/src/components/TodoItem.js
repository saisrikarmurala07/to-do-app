import React from "react";

export default function TodoItem({ task, onToggle, onDelete }) {
  return (
    <li className={`todo__item${task.completed ? " todo__item--done" : ""}`}>
      <button
        className="todo__check"
        role="checkbox"
        aria-checked={task.completed}
        aria-label={
          task.completed
            ? `Mark "${task.text}" as not done`
            : `Mark "${task.text}" as done`
        }
        onClick={() => onToggle(task.id)}
      >
        {task.completed && (
          <svg viewBox="0 0 16 16" width="11" height="11" aria-hidden="true">
            <path
              d="M2.5 8.5L6 12l7.5-8"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </button>

      <span className="todo__text">{task.text}</span>

      <button
        className="todo__delete"
        aria-label={`Delete "${task.text}"`}
        onClick={() => onDelete(task.id)}
      >
        Remove
      </button>
    </li>
  );
}
