import React from "react";

export default function TabNav({ tabs, activeTab, onChange }) {
  return (
    <nav className="tabnav" role="tablist" aria-label="Ledger sections">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          role="tab"
          aria-selected={activeTab === tab.id}
          className={`tabnav__tab${
            activeTab === tab.id ? " tabnav__tab--active" : ""
          }`}
          onClick={() => onChange(tab.id)}
        >
          {tab.label}
        </button>
      ))}
    </nav>
  );
}
