import React, { useState } from "react";
import "./Todo.css";
import TodoItem from "./TodoItem";

const FILTERS = {
  all: () => true,
  active: (task) => !task.completed,
  done: (task) => task.completed,
};

let nextId = 4;

const initialTasks = [
  { id: 1, text: "Sketch the component tree", completed: true },
  { id: 2, text: "Wire up task state with useState", completed: true },
  { id: 3, text: "Style the folder-tab navigation", completed: false },
];

export default function TodoApp() {
  const [tasks, setTasks] = useState(initialTasks);
  const [draft, setDraft] = useState("");
  const [filter, setFilter] = useState("all");

  const remaining = tasks.filter((task) => !task.completed).length;
  const visibleTasks = tasks.filter(FILTERS[filter]);

  const handleAdd = (event) => {
    event.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setTasks((prev) => [...prev, { id: nextId++, text, completed: false }]);
    setDraft("");
  };

  const handleToggle = (id) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const handleDelete = (id) => {
    setTasks((prev) => prev.filter((task) => task.id !== id));
  };

  return (
    <section aria-labelledby="tasks-heading">
      <div className="todo__intro">
        <h2 id="tasks-heading" className="todo__heading">
          Today's line
        </h2>
        <p className="todo__sub">
          {remaining === 0
            ? "Everything on the list is done."
            : `${remaining} task${remaining === 1 ? "" : "s"} left to clear.`}
        </p>
      </div>

      <form className="todo__form" onSubmit={handleAdd}>
        <input
          className="todo__input"
          type="text"
          placeholder="Add a task…"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          aria-label="New task"
        />
        <button className="todo__add" type="submit">
          Add task
        </button>
      </form>

      <div className="todo__filters" role="tablist" aria-label="Filter tasks">
        {Object.keys(FILTERS).map((key) => (
          <button
            key={key}
            className={`todo__filter${
              filter === key ? " todo__filter--active" : ""
            }`}
            onClick={() => setFilter(key)}
          >
            {key === "all" ? "All" : key === "active" ? "Active" : "Done"}
          </button>
        ))}
      </div>

      {visibleTasks.length === 0 ? (
        <p className="todo__empty">
          {filter === "done"
            ? "Nothing finished yet — check something off."
            : filter === "active"
            ? "No open tasks. Add one above."
            : "The ledger is empty. Add your first task."}
        </p>
      ) : (
        <ul className="todo__list">
          {visibleTasks.map((task) => (
            <TodoItem
              key={task.id}
              task={task}
              onToggle={handleToggle}
              onDelete={handleDelete}
            />
          ))}
        </ul>
      )}
    </section>
  );
}
