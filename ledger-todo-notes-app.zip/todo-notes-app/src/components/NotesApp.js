import React, { useState } from "react";
import "./Notes.css";
import NoteCard from "./NoteCard";

const HUES = ["gold", "moss", "clay", "slate"];
let nextId = 3;

const initialNotes = [
  {
    id: 1,
    title: "Component ideas",
    body: "Split TodoItem and NoteCard out so they stay reusable and easy to test.",
    hue: "gold",
  },
  {
    id: 2,
    title: "Props vs state",
    body: "Lift state only as high as the components that need to share it — App just owns the active tab.",
    hue: "moss",
  },
];

export default function NotesApp() {
  const [notes, setNotes] = useState(initialNotes);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const handleCreate = (event) => {
    event.preventDefault();
    const trimmedTitle = title.trim();
    const trimmedBody = body.trim();
    if (!trimmedTitle && !trimmedBody) return;

    const hue = HUES[notes.length % HUES.length];
    setNotes((prev) => [
      { id: nextId++, title: trimmedTitle || "Untitled", body: trimmedBody, hue },
      ...prev,
    ]);
    setTitle("");
    setBody("");
  };

  const handleUpdate = (id, updates) => {
    setNotes((prev) =>
      prev.map((note) => (note.id === id ? { ...note, ...updates } : note))
    );
  };

  const handleDelete = (id) => {
    setNotes((prev) => prev.filter((note) => note.id !== id));
  };

  return (
    <section aria-labelledby="notes-heading">
      <div className="notes__intro">
        <h2 id="notes-heading" className="notes__heading">
          Index cards
        </h2>
        <p className="notes__sub">
          {notes.length} note{notes.length === 1 ? "" : "s"} pinned to the board.
        </p>
      </div>

      <form className="notes__form" onSubmit={handleCreate}>
        <input
          className="notes__title-input"
          type="text"
          placeholder="Note title…"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          aria-label="New note title"
        />
        <textarea
          className="notes__body-input"
          placeholder="Write something worth keeping…"
          rows={3}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          aria-label="New note body"
        />
        <button className="notes__add" type="submit">
          Pin note
        </button>
      </form>

      {notes.length === 0 ? (
        <p className="notes__empty">The board is clear. Pin your first note.</p>
      ) : (
        <div className="notes__grid">
          {notes.map((note) => (
            <NoteCard
              key={note.id}
              note={note}
              onUpdate={handleUpdate}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </section>
  );
}
